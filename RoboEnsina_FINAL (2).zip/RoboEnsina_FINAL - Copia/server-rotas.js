const express = require('express');
const path = require('path');

const hostname = '127.0.0.1';
const port = 3000;

const app = express();

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/produtoA.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'produtoA.html'));
});

app.get('/produtoB.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'produtoB.html'));
});

app.get('/produtoC.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'produtoC.html'));
});

// importar e expor outras rotas (se estiver usando)
const clienteRotas = require('./routes/Cliente');
const produtoRotas = require('./routes/Produto');

app.use('/cliente', clienteRotas);
app.use('/produto', produtoRotas);

app.listen(port, hostname, () => {
  console.log(`Servidor rodando em http://${hostname}:${port}/`);
});
